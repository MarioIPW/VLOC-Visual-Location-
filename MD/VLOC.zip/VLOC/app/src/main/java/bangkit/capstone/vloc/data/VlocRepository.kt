package bangkit.capstone.vloc.data

import androidx.lifecycle.LiveData
import androidx.paging.ExperimentalPagingApi
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import androidx.paging.liveData
import bangkit.capstone.vloc.data.local.database.Favorites
import bangkit.capstone.vloc.data.local.database.VlocDatabase
import bangkit.capstone.vloc.data.local.pref.UserPreference
import bangkit.capstone.vloc.data.model.DetailsLocationResponse
import bangkit.capstone.vloc.data.model.FavoritesResponse
import bangkit.capstone.vloc.data.model.LocationResponseItem
import bangkit.capstone.vloc.data.model.LoginRequest
import bangkit.capstone.vloc.data.model.LoginResponse
import bangkit.capstone.vloc.data.model.PostResponse
import bangkit.capstone.vloc.data.model.PredictResponse
import bangkit.capstone.vloc.data.model.RegisterRequest
import bangkit.capstone.vloc.data.model.UserModel
import bangkit.capstone.vloc.data.model.UserResponseItem
import bangkit.capstone.vloc.data.paging.VlocRemoteMediator
import bangkit.capstone.vloc.data.remote.ApiService
import kotlinx.coroutines.flow.Flow
import okhttp3.MultipartBody


class VlocRepository private constructor(
    private val userPreference: UserPreference,
    private val apiService: ApiService,
    private val vlocDatabase: VlocDatabase,
) {

    // pref session login
    suspend fun saveSession(user: UserModel) {
        userPreference.saveSession(user)
    }

    fun getSession(): Flow<UserModel> {
        return userPreference.getSession()
    }

    suspend fun logout() {
        userPreference.logout()
    }

    suspend fun postRegister(user: RegisterRequest): PostResponse {
        return apiService.register(user)
    }

    suspend fun postLogin(user: LoginRequest): LoginResponse {
        return apiService.login(user)
    }

    suspend fun getUserDetails(userId: String): UserResponseItem {
        return apiService.getUserDetails(userId)
    }

    suspend fun changePhotoProfile(userId: String, file: MultipartBody.Part): PostResponse {
        return apiService.changePhotoProfile(userId, file)
    }


    suspend fun getDetailsLocation(idLocation: String): DetailsLocationResponse {
        return apiService.getDetailsLocation(idLocation)
    }


    suspend fun getUserFavorites(userId: String): FavoritesResponse {
        return apiService.getUserFavorites(userId)
    }

    suspend fun postFavorite(userId: String, locationId: String): PostResponse {
        return apiService.postFavorite(userId, locationId)
    }

    suspend fun deleteFavorite(userId: String, locationId: String): PostResponse {
        return apiService.deleteFavorite(userId, locationId)
    }

    suspend fun predictLocation(file: MultipartBody.Part): PredictResponse {
        return apiService.predictLocation(file)
    }

    // database
    fun getDestination(category: String?): LiveData<PagingData<LocationResponseItem>> {

        @OptIn(ExperimentalPagingApi::class)
        return Pager(
            config = PagingConfig(
                pageSize = 5
            ),
            remoteMediator = VlocRemoteMediator(vlocDatabase, apiService, category),
            pagingSourceFactory = {
                vlocDatabase.vlocDao().getAllLocation()
            }
        ).liveData
    }


    suspend fun postFavorite(data: Favorites) {
        return vlocDatabase.favoritesDao().insert(data)
    }
    suspend fun deleteFavorite(data: Favorites) {
        return vlocDatabase.favoritesDao().delete(data)
    }

    fun checkFavorites(id: String?): LiveData<Boolean> {
        return vlocDatabase.favoritesDao().isFavoriteUser(id)
    }

    fun getAllFavorites(): LiveData<List<Favorites>> = vlocDatabase.favoritesDao().getFavorites()



    companion object {
        @Volatile
        private var instance: VlocRepository? = null
        fun getInstance(
            userPreference: UserPreference,
            apiService: ApiService,
            vlocDatabase: VlocDatabase
        ): VlocRepository =
            instance ?: synchronized(this) {
                instance ?: VlocRepository(userPreference, apiService, vlocDatabase)
            }.also { instance = it }
    }
}