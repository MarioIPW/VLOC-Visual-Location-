package bangkit.capstone.vloc.data.model

import com.google.gson.annotations.SerializedName
import retrofit2.http.Field

data class UserModel(
	val id: String,
	val name: String,
	val email: String,
	val token: String,
	val isLogin: Boolean = false
)


data class LoginResponse(

	@field:SerializedName("loginResult")
	val loginResult: LoginResult,

	@field:SerializedName("error")
	val error: Boolean,

	@field:SerializedName("message")
	val message: String
)


data class LoginResult(

	@field:SerializedName("name")
	val name: String,

	@field:SerializedName("userId")
	val userId: String,

	@field:SerializedName("token")
	val token: String
)

data class LoginRequest(
	@Field("email")
	val email: String,
	@Field("password")
	val password: String
)

data class PostResponse(

	@field:SerializedName("error")
	val error: Boolean,

	@field:SerializedName("message")
	val message: String
)

data class RegisterRequest (
	@Field("name")
	val name: String,
	@Field("email")
	val email: String,
	@Field("password")
	val password: String
)
data class UserResponseItem(

	@field:SerializedName("createdAt")
	val createdAt: String,

	@field:SerializedName("image")
	val image: String,

	@field:SerializedName("password")
	val password: String,

	@field:SerializedName("updateAt")
	val updateAt: String,

	@field:SerializedName("id")
	val id: Int,

	@field:SerializedName("email")
	val email: String,

	@field:SerializedName("username")
	val username: String
)
