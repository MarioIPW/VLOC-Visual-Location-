package bangkit.capstone.vloc.ui.details

class RecomendationAdapter {
}