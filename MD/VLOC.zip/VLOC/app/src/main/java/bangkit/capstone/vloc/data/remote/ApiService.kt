package bangkit.capstone.vloc.data.remote

import bangkit.capstone.vloc.data.model.DetailsLocationResponse
import bangkit.capstone.vloc.data.model.FavoritesResponse
import bangkit.capstone.vloc.data.model.LocationResponse
import bangkit.capstone.vloc.data.model.LoginRequest
import bangkit.capstone.vloc.data.model.LoginResponse
import bangkit.capstone.vloc.data.model.PostResponse
import bangkit.capstone.vloc.data.model.PredictResponse
import bangkit.capstone.vloc.data.model.RegisterRequest
import bangkit.capstone.vloc.data.model.UserResponseItem
import okhttp3.MultipartBody
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.Field
import retrofit2.http.GET
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {
    @POST("register")
    suspend fun register(
        @Body user: RegisterRequest
    ): PostResponse

    @POST("login")
    suspend fun login(
        @Body user: LoginRequest
    ): LoginResponse

    @GET("users/{id_user}")
    suspend fun getUserDetails(
        @Path("id_user") userId: String
    ): UserResponseItem

    @Multipart
    @POST("users/profile/{user_id}")
    suspend fun changePhotoProfile(
        @Path("user_id") userId: String,
        @Part file: MultipartBody.Part
    ): PostResponse

    @GET("location")
    suspend fun getAllLocation(
        @Query("page") page: Int = 1,
        @Query("size") size: Int = 20
    ): LocationResponse

    @GET("location/{id_location}")
    suspend fun getDetailsLocation(
        @Path("id_location") idLocation: String
    ) : DetailsLocationResponse

    @GET("/location")
    fun getLocationByCategory(
        @Query("category") category: String,
        @Query("page") page: Int = 1,
        @Query("size") size: Int = 20
    ):  LocationResponse

    @GET("favorite/{user_id}")
    suspend fun getUserFavorites(
        @Path("user_id") userId: String
    ): FavoritesResponse

    @POST("favorite/{user_id}")
    suspend fun postFavorite(
        @Path("user_id") userId: String,
        @Field("location_id") locationId: String
    ): PostResponse

    @DELETE("favorite/{user_id}")
    suspend fun deleteFavorite(
        @Path("user_id") userId: String,
        @Field("location_id") locationId: String
    ): PostResponse


    @Multipart
    @POST("predict")
    suspend fun predictLocation(
        @Part file: MultipartBody.Part
    ): PredictResponse

}