package bangkit.capstone.vloc.ui.profile

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import bangkit.capstone.vloc.R
import bangkit.capstone.vloc.ViewModelFactory
import bangkit.capstone.vloc.data.local.database.Favorites
import bangkit.capstone.vloc.databinding.FragmentProfileBinding
import bangkit.capstone.vloc.setting.SettingsActivity
import bangkit.capstone.vloc.ui.search.SearchFragment
import bangkit.capstone.vloc.ui.uriToFile
import com.bumptech.glide.Glide
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.transition.MaterialFadeThrough
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody

class ProfileFragment : Fragment() {

    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding

    private val viewModel by viewModels<ProfileViewModel> {
        ViewModelFactory.getInstance(requireContext())
    }

    private var currentImageUri: Uri? = null

    private val adapter = FavoritesAdapter()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)

        enterTransition = MaterialFadeThrough()

        val layoutManager = StaggeredGridLayoutManager(2, LinearLayoutManager.VERTICAL)
        binding?.rvDestination?.layoutManager = layoutManager

        return binding?.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        setToolbar()
        showProfile()
        showFavorites()

        binding?.btnChange?.setOnClickListener {startGallery()}

        super.onViewCreated(view, savedInstanceState)
    }

    private fun setToolbar() {
        binding?.profileToolbar?.inflateMenu(R.menu.profile_menu)

        binding?.profileToolbar?.setOnMenuItemClickListener {
            when(it.itemId){
                R.id.settings_action -> {
                    startActivity(Intent(requireActivity(), SettingsActivity::class.java))
                }
            }
            true
        }
    }
    private fun showProfile() {
        viewModel.getSession().observe(viewLifecycleOwner) {
            viewModel.getUserDetails(it.id)
            viewModel.getUserFavorites(it.id)
            if (it.isLogin) {
                viewModel.response.observe(viewLifecycleOwner) { user ->
                    binding?.nameProfile?.text = user.username
                    Glide.with(requireActivity())
                        .load(user.image)
                        .into(binding?.imgProfile!!)
                }
            } else {
                binding?.nameProfile?.text = getString(R.string.guest)
                showSnackbar(getString(R.string.you_haven_t_login_yet))
            }
        }
    }

    private fun showFavorites() {
//        viewModel.favResponse.observe(viewLifecycleOwner) { favorites ->
//            val items = arrayListOf<Favorites>()
//            favorites.favorite.map {
//                val item = Favorites(id = it.id.toString(), destinationUrl = it.destinationImgUrl, timeStamp = it.userId.toLong())
//                items.add(item)
//            }
//            adapter.submitList(items)
//            binding?.rvDestination?.adapter = adapter
//
//        }


        // local database
        viewModel.getFavorites().observe(viewLifecycleOwner) { favorites ->
            val items = arrayListOf<Favorites>()
            favorites.map {
                val item = Favorites(id = it.id, destinationUrl = it.destinationUrl, timeStamp = it.timeStamp)
                items.add(item)
            }
            adapter.submitList(items)
            binding?.rvDestination?.adapter = adapter
        }
    }
    private fun showSnackbar(message: String) {
        Snackbar.make(
            requireView(),
            message,
            Snackbar.LENGTH_SHORT
        ).show()
    }

    private fun startGallery() {
        showSnackbar("okeee")
        launcherGallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    private val launcherGallery = registerForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            currentImageUri = uri
            showImage()
        } else {
            Log.d(SearchFragment.TAG, getString(R.string.media_not_selected))
        }
    }

    private fun showImage() {
        viewModel.getSession().observe(viewLifecycleOwner) { user ->
            val token = "Bearer ${user.token}"
            if (token.isNotEmpty()) {
                changePhotoProfile(user.id)
            } else {
                showSnackbar(getString(R.string.failed_message))
            }
        }
        currentImageUri?.let {
            binding?.imgProfile?.setImageURI(it)
        }
    }

    private fun changePhotoProfile(userId: String) {
        currentImageUri?.let { uri ->
            val imageFile = uriToFile(uri, requireContext())

            val requestImageFile = imageFile.asRequestBody("image/jpeg".toMediaType())
            val multipartBody = MultipartBody.Part.createFormData(
                "photo",
                imageFile.name,
                requestImageFile
            )
            viewModel.changeProfile(userId, multipartBody)
        } ?: showSnackbar(getString(R.string.warning))
    }


}