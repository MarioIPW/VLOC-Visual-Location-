package bangkit.capstone.vloc.ui.details

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import bangkit.capstone.vloc.R
import bangkit.capstone.vloc.ViewModelFactory
import bangkit.capstone.vloc.data.local.database.Favorites
import bangkit.capstone.vloc.databinding.FragmentDetailsBinding
import com.bumptech.glide.Glide
import com.google.android.material.transition.MaterialFadeThrough
import kotlinx.coroutines.launch
import java.util.Calendar

@Suppress("DEPRECATION")
class DetailsFragment : Fragment() {

    private var _binding: FragmentDetailsBinding? = null
    private val binding get() = _binding

    private val viewModel by viewModels<DetailsViewModel> {
        ViewModelFactory.getInstance(requireContext())
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentDetailsBinding.inflate(inflater, container, false)
        val destinationId = arguments?.getString("destinationId")

        exitTransition = MaterialFadeThrough()

        lifecycleScope.launch {
            viewModel.getDetails(destinationId!!)
        }

        openMaps(" -7.75", "110.49417")

        viewModel.location.observe(viewLifecycleOwner) { response ->
            binding?.tvdetail?.text = response?.destionation?.destinationDetails
            binding?.tvname?.text = response?.destionation?.destinationName
            binding?.htmNominal?.text = getString(R.string.htm_price, response?.destionation?.fee)
            binding?.tvTime?.text = getString(R.string.time_placeholder, response?.destionation?.openTime)
            binding?.ratingScore?.text = getString(R.string.rating_score, response?.destionation?.rating)
            binding?.ivdetail?.let { imageView ->
                Glide.with(imageView)
                    .load(response?.destionation?.destinationImgUrl)
                    .into(imageView)
            }
            // add fav actions
            addRemoveFavorites(destinationId!!, response?.destionation?.destinationImgUrl)
        }
        return binding?.root
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        binding?.detailsToolbar?.setNavigationOnClickListener {
            requireActivity().onBackPressed()
        }
    }

    private fun addRemoveFavorites(id: String, url: String?) {
        val timestamp = getTimestamp()
        val data = Favorites(id, url, timestamp)
        viewModel.checkFavoriteStatus(id).observe(viewLifecycleOwner) { isFav ->
            if (isFav) {
                binding?.btnFav?.setImageDrawable(
                    ContextCompat.getDrawable(requireActivity(), R.drawable.ic_fav)
                )
            } else {
                binding?.btnFav?.setImageDrawable(
                    ContextCompat.getDrawable(requireActivity(), R.drawable.ic_fav_border)
                ) }

            binding?.btnFav?.setOnClickListener{
                if (!isFav){
                    viewModel.sendFav(data)
                } else {
                    viewModel.deleteFav(data)
                }

            }
        }

    }

    private fun openMaps(latitude: String, longitude: String) {
        val mapUri = Uri.parse("https://maps.google.com/maps?daddr=$latitude,$longitude")
        val intent = Intent(Intent.ACTION_VIEW, mapUri)

        binding?.btnMaps?.setOnClickListener{
            startActivity(intent)
        }
    }


    private fun getTimestamp(): Long {
        val calendar = Calendar.getInstance()
        return calendar.timeInMillis
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

}