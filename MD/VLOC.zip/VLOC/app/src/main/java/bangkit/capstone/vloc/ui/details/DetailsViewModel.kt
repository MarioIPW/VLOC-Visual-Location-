package bangkit.capstone.vloc.ui.details

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import bangkit.capstone.vloc.data.VlocRepository
import bangkit.capstone.vloc.data.local.database.Favorites
import bangkit.capstone.vloc.data.model.DetailsLocationResponse
import bangkit.capstone.vloc.data.model.PostResponse
import bangkit.capstone.vloc.data.model.UserModel
import com.google.gson.Gson
import kotlinx.coroutines.launch
import retrofit2.HttpException

class DetailsViewModel(private val repository: VlocRepository) : ViewModel() {

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading


    private val _error = MutableLiveData<String>()
    val error: LiveData<String> = _error

    private val _location = MutableLiveData<DetailsLocationResponse>()
    val location: LiveData<DetailsLocationResponse> = _location

    fun getSession(): LiveData<UserModel> {
        return repository.getSession().asLiveData()
    }

    fun sendFav(data: Favorites) {
        _isLoading.value = false
        viewModelScope.launch {
            try {
                _isLoading.value = true
                repository.postFavorite(data)
            } catch (e: HttpException) {
                val errorBody = e.response()?.errorBody()?.string()
                Gson().fromJson(errorBody, PostResponse::class.java)
                _isLoading.value = false
            }
        }
    }

    fun deleteFav(data: Favorites) {
        _isLoading.value = false
        viewModelScope.launch {
            try {
                _isLoading.value = true
                repository.deleteFavorite(data)
            } catch (e: HttpException) {
                val errorBody = e.response()?.errorBody()?.string()
                Gson().fromJson(errorBody, PostResponse::class.java)
                _isLoading.value = false
            }
        }
    }

    fun getFavorites() = repository.getAllFavorites()
    fun checkFavoriteStatus(id: String?): LiveData<Boolean> {
        return repository.checkFavorites(id)
    }

    suspend fun getDetails(destinationId: String) {
        _isLoading.value = true
        try {
            val response = repository.getDetailsLocation(destinationId)
            _location.value = response
        } catch (e: HttpException) {
            _error.value = "Error fetching details"
        } finally {
            _isLoading.value = false
        }
    }
}
